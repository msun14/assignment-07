# 🛒 বাজার দর — BazarDor

**B14-A7 · A Bangla market-price dashboard built with Next.js, TypeScript, and Better Auth.**

Compare everyday essentials across markets, see the day's biggest price changes, and sign in to view detailed market comparisons. The interface follows the seven supplied design references: pale green surfaces, rounded cards, compact Bangla typography, category navigation, a price ticker, and account screens.

## Start here

**For Netlify, follow [NETLIFY_SETUP.md](./NETLIFY_SETUP.md).** This is a full-stack Next.js application, so deploy through a Netlify build connected to a Git repository. Uploading the source ZIP to Netlify Drop does not deploy the authentication server.

The ZIP contains the complete application source, dependency lockfile, database migration, tests, deployment configuration, and actual Git history. Install dependencies with `npm ci`. Generated dependencies, build output, and private credentials are intentionally excluded.

## Features

1. Responsive Bangla UI for mobile, tablet, and desktop, with a self-hosted Hind Siliguri font.
2. Eight category links, active-category highlighting, and a seamless ticker with pause and reduced-motion support.
3. Home hero with a same-page `#সব-পণ্য` anchor, six price risers, six fallers, and the full catalogue.
4. Clickable product cards with readable `/product/[slug]` URLs and Bengali prices and percentages.
5. Protected product details, actual minimum/maximum prices, average market prices, and all supplied market rows.
6. Category sorting by numeric price, including normalization of Bengali-digit data.
7. Better Auth email/password registration and login, Google and GitHub OAuth, secure cookies, and persistent PostgreSQL sessions.
8. Registration returns to sign-in; protected-page login returns to the requested product. Direct login opens Home.
9. Profile display and a separate `/profile/edit` route using Better Auth's `updateUser`.
10. Toasts, inline validation, loading skeletons, error boundaries, friendly unknown-route pages, and a clearly labelled API snapshot fallback.

No email verification or password-reset flow is required or enabled for the assignment.

## Technologies

| Layer | Technology |
| --- | --- |
| Framework and routing | Next.js 16.4, App Router, React 19.3 |
| Language | TypeScript |
| Styling | Tailwind CSS 4, custom responsive components |
| Accessible component library | Radix UI dropdown menu |
| Icons and notifications | Lucide, react-hot-toast |
| Authentication | Better Auth 1.7.7 |
| Persistent data | PostgreSQL, Drizzle ORM, node-postgres |
| Deployment | Netlify's automatic Next.js/OpenNext adapter |
| Tests | Node test runner, TSX, PGlite for isolated PostgreSQL-compatible auth tests |

All direct package versions are pinned in `package.json` and `package-lock.json`.

## Local setup

Use Node **22.16+** or Node 24. Node 22 is configured for Netlify.

```bash
npm ci
```

Copy `.env.example` to `.env.local`. On Windows PowerShell:

```powershell
Copy-Item .env.example .env.local
```

On macOS/Linux:

```bash
cp .env.example .env.local
```

Set `DATABASE_URL` to a persistent PostgreSQL connection, generate a `BETTER_AUTH_SECRET`, and set `BETTER_AUTH_URL=http://localhost:3000`. Then:

```bash
npm run check:env
npm run db:migrate
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Create an account at `/signup`, then sign in. No seeded credentials or fake local-storage accounts are used.

Google and GitHub sign-in need your own OAuth applications and callback URLs. Both buttons are wired; an unconfigured provider is unavailable instead of pretending to authenticate. Email/password works independently once the database and auth variables are configured.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string; use your provider's pooled URL and TLS parameters |
| `BETTER_AUTH_SECRET` | Random secret of at least 32 characters; keep it stable across deployments |
| `BETTER_AUTH_URL` | Exact origin, e.g. `https://your-site.netlify.app`; no `/api/auth` suffix |
| `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` | Google OAuth credentials |
| `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET` | GitHub OAuth credentials |
| `BAZARDOR_API_URL` | Optional API base override; defaults to the official assignment endpoint |
| `BETTER_AUTH_TRUSTED_ORIGINS` | Optional additional exact origins, comma-separated |
| `REQUIRE_SOCIAL_AUTH` | Set `true` for final submission to block deployment when either social provider is missing |

Secrets remain on the server. None use the `NEXT_PUBLIC_` prefix.

## Routes

| Route | Access / behavior |
| --- | --- |
| `/` | Public home |
| `/category/[slug]` | Public category and price sorting |
| `/product/[slug]` | Server-validated login required |
| `/product/1` | ID alias redirects to the canonical slug after sign-in |
| `/signin`, `/signup` | Account forms and social login |
| `/profile` | Protected profile summary |
| `/profile/edit` | Protected name update |
| `/api/auth/[...all]` | Better Auth route handler |
| Unknown category, product or path | Friendly not-found view and Home link |

The application keeps full dynamic routing. There is no static export and no catch-all SPA redirect, so the hosting adapter can handle direct loads and refreshes.

## API and calculations

Base: `https://openapi.programming-hero.com/api/bazardor`

- `/products`
- `/products?category=chal`
- `/products/1`
- `/categories`
- `/categories/chal`

The live API returned **33 products across eight categories** when this project was created. Requests happen on the server, with a seven-second timeout and five-minute revalidation. The readable product slug is resolved to its API ID before requesting single-product details.

If a request fails, the bundled unmodified API snapshot is used, with a visible saved-data notice and its capture date. The fallback never silently claims to be fresh live prices. An empty successful category response stays empty.

Market average = `(minimum + maximum) / 2`. The summary average is the mean of those market midpoints; the API's `today` value remains the separate headline price. The written brief specifies **green up, red down, gray flat**, so those colours take precedence over the opposite convention in the reference screenshots. Profile editing is separate to satisfy Challenge C3.

## Commands

```bash
npm run dev           # Local development
npm run check:env     # Validate configuration without printing secrets
npm run db:migrate    # Create persistent auth tables; safe to rerun
npm run typecheck     # TypeScript checks
npm test              # Data, validation, security and real Better Auth tests
npm run build         # Next.js production compilation
npm run test:routes   # Production request smoke checks; run after build
npm start            # Serve the production build locally
```

On Netlify, `npm run build:netlify` checks environment variables, applies the idempotent PostgreSQL migration, and builds Next.js. A database/configuration failure stops deployment with an actionable message instead of publishing a known-broken sign-in flow. Additional future schema changes should use new versioned migrations.

## Project map

```text
src/app/           App Router pages, route handlers, loading and error views
src/components/    Reusable UI and interactive auth/profile components
src/lib/           API normalization, formatting, validation, auth and database
src/data/          Official API snapshot and source/capture metadata
database/          PostgreSQL auth schema migration
scripts/           Environment checks, migration and request smoke checks
tests/             Unit and auth integration tests
public/            Local market-basket vector illustration
netlify.toml       Netlify build configuration
```

## Git history

The included `.git` folder contains more than eight real, meaningful commits. Keep it when extracting if you want to preserve that history. Before pushing, optionally update the local author settings for future commits:

```bash
git config user.name "Your Name"
git config user.email "you@example.com"
git log --oneline
git remote add origin https://github.com/YOUR_USERNAME/bazar-dor.git
git push -u origin main
```

The repository has no configured remote. The existing commits use the neutral `BazarDor Project` author name.

## Verification and deployment status

See [docs/VERIFICATION.md](./docs/VERIFICATION.md) for the exact tested scope. A successful local build is not a live Netlify deployment. Real Google/GitHub consent and production database connectivity require your credentials and final domain.

## Official references

- [Better Auth: Next.js integration](https://better-auth.com/docs/integrations/next)
- [Better Auth: email/password](https://better-auth.com/docs/authentication/email-password)
- [Better Auth: update user](https://better-auth.com/docs/concepts/users-accounts#update-user)
- [Better Auth: Google](https://better-auth.com/docs/authentication/google)
- [Better Auth: GitHub](https://better-auth.com/docs/authentication/github)
- [Next.js on Netlify](https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/)
