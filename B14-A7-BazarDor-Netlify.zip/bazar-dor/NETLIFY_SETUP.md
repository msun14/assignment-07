# Deploy BazarDor on Netlify

This app needs a Netlify build, a persistent PostgreSQL database, and authentication credentials. The source ZIP is not a static drag-and-drop deployment.

## 1. Extract and push the project

Extract `B14-A7-BazarDor-Netlify.zip`. Open the **bazar-dor** folder, which contains `package.json` and `netlify.toml`. Preserve its `.git` folder to retain the included commit history.

Create an empty repository in your Git provider, then push the project:

```bash
git remote add origin https://github.com/YOUR_USERNAME/bazar-dor.git
git push -u origin main
```

For Netlify, connect that repository. If `package.json` is at the repository root, leave the base directory empty. If you pushed the enclosing folder instead, set the base directory to `bazar-dor`.

## 2. Create the database

Use a PostgreSQL provider such as Neon or Supabase. Copy its connection URL, including TLS parameters. Use the provider's pooled connection suitable for serverless functions. For a pooler with transaction restrictions, use a connection endpoint that permits the schema migration in this project.

Do not use `localhost`, an in-memory database, or a SQLite file on the Netlify function filesystem. Accounts must survive new function instances and redeployments.

The database user must be able to create the four Better Auth tables. The production build runs `database/001_auth.sql` automatically. The script uses a transaction and advisory lock and never drops accounts. You can also run it locally with `npm run db:migrate`.

## 3. Choose the final site address

Create the Netlify project and choose its site name, e.g. `your-bazar-dor.netlify.app`. If the first build starts before environment variables are entered, it will intentionally fail the configuration check; add the variables and redeploy.

Use the same exact HTTPS origin everywhere. If adding a custom domain, set it as the primary domain, update `BETTER_AUTH_URL` and OAuth callbacks, and redeploy.

## 4. Add environment variables

In the Netlify project's environment settings, add the following with **Builds and Functions** availability. Do not put secrets in `netlify.toml` or commit `.env.local`.

| Key | Value |
| --- | --- |
| `DATABASE_URL` | Your complete PostgreSQL URL |
| `BETTER_AUTH_SECRET` | Your generated random secret |
| `BETTER_AUTH_URL` | `https://YOUR-SITE.netlify.app` |
| `GOOGLE_CLIENT_ID` | Google OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | Google OAuth client secret |
| `GITHUB_CLIENT_ID` | GitHub OAuth client ID |
| `GITHUB_CLIENT_SECRET` | GitHub OAuth client secret |
| `REQUIRE_SOCIAL_AUTH` | `true` for the final assignment |

Generate a secret locally:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

Keep the secret unchanged across normal deployments. No auth variables require `NEXT_PUBLIC_`. The client calls `/api/auth` on the current origin, avoiding hard-coded localhost and cross-origin cookie failures.

## 5. Configure Google

In Google Cloud, create an OAuth client for a **Web application**. Configure the consent screen and allowed audience. If the app is in testing mode, add the examiner as a test user or publish the consent configuration for the intended users.

**Authorized JavaScript origin:**

```text
https://YOUR-SITE.netlify.app
```

**Authorized redirect URI — copy exactly:**

```text
https://YOUR-SITE.netlify.app/api/auth/callback/google
```

For local testing, also allow `http://localhost:3000` and `http://localhost:3000/api/auth/callback/google`.

## 6. Configure GitHub

In GitHub Developer settings, register an OAuth App. Use:

```text
Homepage URL: https://YOUR-SITE.netlify.app
Authorization callback URL: https://YOUR-SITE.netlify.app/api/auth/callback/github
```

Copy its client ID and secret to Netlify. The app requests `read:user` and `user:email`. A separate OAuth App is the simplest way to maintain a localhost callback alongside a production callback.

## 7. Build and deploy

The included `netlify.toml` supplies:

```text
Build command: npm run build:netlify
Publish directory: .next
Node version: 22
```

Netlify detects Next.js and installs its current OpenNext adapter automatically. Do not change the publish folder to `out`, enable static export, or add `/* /index.html 200`. Those changes would break server authentication and dynamic routes.

After adding or changing environment variables, trigger a new deployment. Wait for the successful deploy result before testing.

Deploy previews and branch deploys run `npm run build` without applying migrations to the production database. If you need auth in a preview, explicitly configure that context with an isolated database, its exact origin, and matching OAuth callbacks. Avoid treating random preview domains as production login origins.

## 8. Submission check

1. Open `/signup`; submit a new name, email and matching password of 8+ characters. It should go to `/signin` without an email-verification step.
2. Sign in with the registered email/password. It should open Home and show the real account in the navbar.
3. Click a product. Its `/product/[slug]` page should display market prices; refresh the page.
4. Open `/profile`, follow **তথ্য আপডেট করুন**, change the name and submit. Check the saved name after refreshing.
5. Sign out. Open a product URL directly. It should redirect to sign-in with a toast, and return to that product after login.
6. Try Google and GitHub in a private browser window with the examiner's intended accounts.
7. Check `/category/chal`, both numeric sort orders, and an invalid category/product URL.
8. Resize to 375px, 768px and 1440px. Check horizontal category scrolling, the stacked hero, card grid and horizontally scrollable market table.

## Troubleshooting

| Symptom | Check |
| --- | --- |
| `DATABASE_URL` build error | Set the real database URL for the Builds scope; migration needs a reachable PostgreSQL server |
| Auth returns 503 | Check Functions environment variables, database availability, migration and logs |
| `relation "user" does not exist` | Run `npm run db:migrate` against the same database used by Functions |
| Login succeeds but session is missing | Use the exact configured site origin; inspect secure cookies on HTTPS; keep the secret stable |
| `INVALID_ORIGIN` | Correct `BETTER_AUTH_URL`; add only needed exact additional origins |
| Google `redirect_uri_mismatch` | Copy the exact `/api/auth/callback/google` URL into Google settings |
| GitHub OAuth fails | Check the OAuth App callback domain, client pair and `user:email` scope |
| Social button unavailable | Set both provider variables and redeploy |
| Refresh gives a hosting 404 | Use Netlify's Next.js build/adapter; remove SPA redirects and static export |
| API is unavailable | A dated saved-data banner appears; live fetching resumes when the API recovers |

Better Auth intentionally hides whether an email already exists when automatic sign-in is disabled. Re-registering an email does not replace its password; sign in with the original credentials.
