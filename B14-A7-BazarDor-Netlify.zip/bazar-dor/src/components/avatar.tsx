"use client";
import { useState } from "react";

export function Avatar({ name, image, large = false }: { name: string; image?: string | null; large?: boolean }) {
  const [failed, setFailed] = useState(false);
  const initial = Array.from(name.trim())[0] || "ব";
  return <span className={`avatar ${large ? "avatar-large" : ""}`} aria-hidden="true">
    {image && /^https?:\/\//.test(image) && !failed
      // OAuth avatar hosts vary; no arbitrary image-domain allowlist is required.
      ? <img src={image} width={large ? 72 : 32} height={large ? 72 : 32} alt="" referrerPolicy="no-referrer" onError={() => setFailed(true)} />
      : initial}
  </span>;
}
