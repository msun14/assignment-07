import { getProducts } from "@/lib/api";
import { bn, topMovers } from "@/lib/format";
import { ProductGrid } from "./product-card";
import { DataNotice } from "./data-notice";

export async function HomeCatalog() {
  const { data: products, isFallback } = await getProducts();
  return <><DataNotice show={isFallback} />
    <section className="product-section" aria-labelledby="risers-title">
      <h2 className="section-heading" id="risers-title"><span className="section-arrow change-up" aria-hidden="true">▲</span> আজ দাম বেড়েছে</h2>
      <ProductGrid products={topMovers(products, "up")} />
    </section>
    <section className="product-section" aria-labelledby="fallers-title">
      <h2 className="section-heading" id="fallers-title"><span className="section-arrow change-down" aria-hidden="true">▼</span> আজ দাম কমেছে</h2>
      <ProductGrid products={topMovers(products, "down")} />
    </section>
    <section className="product-section" id="সব-পণ্য" aria-labelledby="all-title">
      <h2 className="section-heading" id="all-title">সব পণ্য</h2>
      <p className="section-subtitle">মোট {bn(products.length)}টি পণ্য দেখানো হচ্ছে</p>
      <ProductGrid products={products} />
    </section>
  </>;
}
