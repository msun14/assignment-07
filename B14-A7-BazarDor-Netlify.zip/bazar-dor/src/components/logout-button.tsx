"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { LogOut } from "lucide-react";
import toast from "react-hot-toast";
import { authClient } from "@/lib/auth-client";

export function LogoutButton({ className = "btn btn-danger" }: { className?: string }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function signOut() {
    setBusy(true);
    try {
      const { error } = await authClient.signOut();
      if (error) throw new Error(error.message);
      toast.success("সফলভাবে সাইন আউট হয়েছে।");
      router.replace("/"); router.refresh();
    } catch { toast.error("সাইন আউট হয়নি। আবার চেষ্টা করুন।"); }
    finally { setBusy(false); }
  }
  return <button type="button" className={className} onClick={signOut} disabled={busy}>
    <LogOut size={15} aria-hidden="true" /> {busy ? "অপেক্ষা করুন…" : "সাইন আউট"}
  </button>;
}
