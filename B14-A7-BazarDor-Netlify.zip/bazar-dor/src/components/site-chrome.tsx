import { getCategories, getProducts } from "@/lib/api";
import { SiteHeader } from "./header";
import { Ticker } from "./ticker";

export async function SiteChrome() {
  const [categories, products] = await Promise.all([getCategories(), getProducts()]);
  return <><SiteHeader categories={categories.data} /><Ticker products={products.data} isFallback={products.isFallback} /></>;
}
export function Footer() {
  return <footer className="site-footer"><div className="container footer-inner">
    <p>বাজার দর — প্রয়োজনীয় পণ্যের দাম এক নজরে।</p>
    <p>সকল দাম সম্ভাব্য; বাজার অবস্থার ওপর নির্ভর করে পরিবর্তিত হয়।</p>
  </div></footer>;
}
