import Link from "next/link";
import { bn, unitLabel } from "@/lib/format";
import type { Product } from "@/lib/types";
import { PriceBadge } from "./price-badge";

export function ProductCard({ product }: { product: Product }) {
  return <Link href={`/product/${product.slug}`} className="product-card" prefetch={false} aria-label={`${product.nameBn} — বিস্তারিত দাম দেখুন`}>
    <div className="product-top">
      <span className="product-emoji" aria-hidden="true">{product.image}</span>
      <div><h3 className="product-title">{product.nameBn}</h3><p className="product-unit">প্রতি {unitLabel(product.unit)}</p></div>
    </div>
    <div className="product-bottom">
      <div><span className="price-label">আজকের দাম</span><p className="price-value">{bn(product.today)}<span className="price-currency">টাকা</span></p></div>
      <PriceBadge change={product.change} />
    </div>
  </Link>;
}
export function ProductGrid({ products }: { products: Product[] }) {
  return <div className="product-grid">{products.map((product) => <ProductCard key={product.id} product={product} />)}</div>;
}
