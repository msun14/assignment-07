import { bn } from "@/lib/format";
import type { Product } from "@/lib/types";

export function PriceBadge({ change, compact = false }: { change: Product["change"]; compact?: boolean }) {
  const symbol = change.dir === "up" ? "▲" : change.dir === "down" ? "▼" : "—";
  const label = change.dir === "up" ? "দাম বেড়েছে" : change.dir === "down" ? "দাম কমেছে" : "দাম অপরিবর্তিত";
  return <span className={`price-badge change-${change.dir} ${compact ? "badge-plain" : ""}`} aria-label={`${label} ${bn(Math.abs(change.pct), 1)} শতাংশ`}>
    {symbol} {bn(Math.abs(change.pct), 1)}%
  </span>;
}
