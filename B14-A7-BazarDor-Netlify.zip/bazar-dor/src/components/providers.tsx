"use client";
import { Suspense, useEffect } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import toast, { Toaster } from "react-hot-toast";
import { authClient } from "@/lib/auth-client";

function RouteNotifications() {
  const search = useSearchParams();
  const path = usePathname();
  useEffect(() => {
    const params = new URLSearchParams(search.toString());
    let changed = false;
    if (params.get("reason") === "protected") {
      toast("বিস্তারিত দেখতে আগে সাইন ইন করুন।", { id: "protected-route", icon: "🔒" });
      params.delete("reason"); changed = true;
    }
    if (params.get("registered") === "1") {
      toast.success("অ্যাকাউন্টের অনুরোধ সম্পন্ন। আপনার ইমেইল ও পাসওয়ার্ড দিয়ে সাইন ইন করুন।", { id: "registered" });
      params.delete("registered"); changed = true;
    }
    if (params.has("error")) {
      toast.error("সাইন ইন সম্পন্ন হয়নি। আবার চেষ্টা করুন।", { id: "oauth-error" });
      params.delete("error"); params.delete("error_description"); changed = true;
    }
    if (params.get("welcome") === "1") {
      void authClient.getSession().then(({ data }) => { if (data) toast.success("সফলভাবে সাইন ইন হয়েছে!", { id: "oauth-welcome" }); });
      params.delete("welcome"); changed = true;
    }
    if (changed) window.history.replaceState(null, "", `${path}${params.size ? `?${params}` : ""}${window.location.hash}`);
  }, [path, search]);
  return null;
}

export function Providers({ children }: { children: React.ReactNode }) {
  return <>
    {children}
    <Toaster position="top-center" toastOptions={{ duration: 4500, style: { fontFamily: "inherit", borderRadius: 12, fontSize: 15, maxWidth: 400 } }} />
    <Suspense><RouteNotifications /></Suspense>
  </>;
}
