"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { ChevronDown, ShoppingCart, UserRound } from "lucide-react";
import { authClient } from "@/lib/auth-client";
import { banglaDate } from "@/lib/format";
import type { Category } from "@/lib/types";
import { Avatar } from "./avatar";
import { LogoutButton } from "./logout-button";

export function DateText({ className = "" }: { className?: string }) {
  const [date, setDate] = useState("");
  useEffect(() => {
    const update = () => setDate(banglaDate());
    update();
    const timer = setInterval(update, 60000);
    return () => clearInterval(timer);
  }, []);
  return <span className={className}>{date || "আজকের বাজার, এক নজরে"}</span>;
}

export function SiteHeader({ categories }: { categories: Category[] }) {
  const path = usePathname();
  const { data: session, isPending } = authClient.useSession();
  return <header className="site-header">
    <div className="container header-top">
      <Link href="/" className="brand" aria-label="বাজার দর — হোম">
        <span className="brand-icon"><ShoppingCart size={24} strokeWidth={1.6} /></span>
        <span><span className="brand-name">বাজার দর</span><DateText className="brand-date" /></span>
      </Link>
      {isPending ? <div className="skeleton auth-placeholder" aria-label="অ্যাকাউন্ট লোড হচ্ছে" /> : session ?
        <DropdownMenu.Root>
          <DropdownMenu.Trigger className="user-trigger" aria-label="ব্যবহারকারীর মেনু">
            <Avatar name={session.user.name} image={session.user.image} />
            <span className="user-name">{session.user.name.split(" ")[0]}</span><ChevronDown size={13} />
          </DropdownMenu.Trigger>
          <DropdownMenu.Portal>
            <DropdownMenu.Content className="user-menu" align="end" sideOffset={12}>
              <div className="menu-identity"><strong>{session.user.name}</strong><span>{session.user.email}</span></div>
              <DropdownMenu.Separator className="menu-divider" />
              <DropdownMenu.Item asChild><Link href="/profile" className="menu-item"><UserRound size={16} /> আমার প্রোফাইল</Link></DropdownMenu.Item>
              <DropdownMenu.Item asChild><LogoutButton className="menu-item menu-signout" /></DropdownMenu.Item>
            </DropdownMenu.Content>
          </DropdownMenu.Portal>
        </DropdownMenu.Root>
        : <div className="auth-actions"><Link href="/signin" className="signin-link">সাইন ইন</Link><Link href="/signup" className="btn btn-primary btn-small">সাইন আপ</Link></div>}
    </div>
    <div className="nav-border"><nav className="container category-nav" aria-label="পণ্যের বিভাগ">
      {categories.map((category) => <Link key={category.slug} href={`/category/${category.slug}`}
        className={`nav-link ${path === `/category/${category.slug}` ? "active" : ""}`} aria-current={path === `/category/${category.slug}` ? "page" : undefined}>
        <span aria-hidden="true">{category.icon}</span>{category.nameBn}
      </Link>)}
    </nav></div>
  </header>;
}
