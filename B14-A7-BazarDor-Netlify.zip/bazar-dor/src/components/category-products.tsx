"use client";
import { useMemo, useState } from "react";
import { ChevronDown } from "lucide-react";
import { bn, sortProducts } from "@/lib/format";
import type { Product, SortOrder } from "@/lib/types";
import { ProductGrid } from "./product-card";

export function CategoryProducts({ products }: { products: Product[] }) {
  const [sort, setSort] = useState<SortOrder>("default");
  const sorted = useMemo(() => sortProducts(products, sort), [products, sort]);
  return <>
    <div className="sort-toolbar surface"><label htmlFor="sort-products">সাজান:</label>
      <span className="select-wrap"><select id="sort-products" className="sort-select" value={sort} onChange={(event) => setSort(event.target.value as SortOrder)}>
        <option value="default">ডিফল্ট</option><option value="asc">দাম: কম থেকে বেশি</option><option value="desc">দাম: বেশি থেকে কম</option>
      </select><ChevronDown className="select-chevron" size={13} aria-hidden="true" /></span>
    </div>
    <p className="section-subtitle" role="status">মোট {bn(products.length)}টি পণ্য দেখানো হচ্ছে</p>
    <ProductGrid products={sorted} />
  </>;
}
