"use client";
import { useState } from "react";
import { Pause, Play } from "lucide-react";
import { bn, unitLabel } from "@/lib/format";
import type { Product } from "@/lib/types";
import { PriceBadge } from "./price-badge";

export function Ticker({ products, isFallback }: { products: Product[]; isFallback: boolean }) {
  const [paused, setPaused] = useState(false);
  const items = products.slice(0, 10);
  return <section className={`ticker ${paused ? "ticker-paused" : ""}`} aria-label={isFallback ? "সংরক্ষিত বাজারদর" : "বাজারদর সংবাদ"}>
    {isFallback && <span className="ticker-saved">সংরক্ষিত</span>}
    <div className="ticker-window"><div className="ticker-track">
      {[0, 1].map((copy) => <div className="ticker-group" key={copy} aria-hidden={copy === 1 ? true : undefined}>
        {items.map((p) => <span className="ticker-item" key={p.id}><span aria-hidden="true">{p.image}</span> {p.nameBn} {bn(p.today)} টাকা/{unitLabel(p.unit)} <PriceBadge change={p.change} compact /></span>)}
      </div>)}
    </div></div>
    <button type="button" className="ticker-toggle" onClick={() => setPaused(!paused)} aria-label={paused ? "দামের চলন্ত সংবাদ চালু করুন" : "দামের চলন্ত সংবাদ থামান"} aria-pressed={paused}>
      {paused ? <Play size={13} /> : <Pause size={13} />}
    </button>
  </section>;
}
