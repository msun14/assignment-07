"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Eye, EyeOff, LoaderCircle } from "lucide-react";
import toast from "react-hot-toast";
import { authClient } from "@/lib/auth-client";
import { safeReturnPath } from "@/lib/format";
import { authErrorMessage, validateAuth, type FormErrors, type FormValues } from "@/lib/validation";

function GithubIcon() {
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 .75a11.25 11.25 0 0 0-3.56 21.92c.56.1.77-.24.77-.54v-2.1c-3.14.68-3.8-1.33-3.8-1.33-.51-1.3-1.25-1.65-1.25-1.65-1.03-.7.08-.69.08-.69 1.14.08 1.74 1.16 1.74 1.16 1.01 1.74 2.65 1.24 3.3.95.1-.74.39-1.25.72-1.53-2.5-.29-5.14-1.25-5.14-5.56 0-1.23.44-2.24 1.16-3.03-.11-.29-.5-1.43.11-2.98 0 0 .95-.31 3.09 1.16A10.75 10.75 0 0 1 12 6.15c.96 0 1.92.13 2.81.38 2.14-1.47 3.08-1.16 3.08-1.16.62 1.55.23 2.69.12 2.98.72.79 1.15 1.8 1.15 3.03 0 4.32-2.64 5.27-5.15 5.55.4.35.76 1.04.76 2.1v3.1c0 .3.21.65.78.54A11.25 11.25 0 0 0 12 .75Z" /></svg>;
}

function GoogleIcon() {
  return <svg width="15" height="15" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.38a4.61 4.61 0 0 1-2 3.03v2.52h3.24c1.9-1.75 2.98-4.32 2.98-7.38Z"/><path fill="#34A853" d="M12 22c2.7 0 4.96-.9 6.62-2.43l-3.24-2.52c-.9.6-2.04.97-3.38.97-2.6 0-4.82-1.76-5.61-4.12H3.04v2.6A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.39 13.9a6 6 0 0 1 0-3.8V7.5H3.04a10 10 0 0 0 0 9l3.35-2.6Z"/><path fill="#EA4335" d="M12 5.98c1.47 0 2.79.51 3.82 1.51l2.87-2.87A9.6 9.6 0 0 0 12 2a10 10 0 0 0-8.96 5.5l3.35 2.6C7.18 7.74 9.4 5.98 12 5.98Z"/></svg>;
}

export function AuthForm({ mode, returnTo, availability }: { mode: "signin" | "signup"; returnTo: string; availability: { ready: boolean; google: boolean; github: boolean } }) {
  const signup = mode === "signup";
  const router = useRouter();
  const [busy, setBusy] = useState<"email" | "google" | "github" | null>(null);
  const [visible, setVisible] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [formError, setFormError] = useState("");
  const next = safeReturnPath(returnTo);
  const otherHref = `/${signup ? "signin" : "signup"}${next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`;

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const values: FormValues = { name: String(data.get("name") || "").trim(), email: String(data.get("email") || "").trim().toLowerCase(), password: String(data.get("password") || ""), confirmPassword: String(data.get("confirmPassword") || "") };
    const validation = validateAuth(values, signup);
    setErrors(validation); setFormError("");
    if (Object.keys(validation).length) {
      toast.error("ফর্মের তথ্যগুলো ঠিক করে আবার চেষ্টা করুন।");
      form.querySelector<HTMLInputElement>(`[name="${Object.keys(validation)[0]}"]`)?.focus();
      return;
    }
    setBusy("email");
    try {
      const result = signup
        ? await authClient.signUp.email({ name: values.name!, email: values.email, password: values.password })
        : await authClient.signIn.email({ email: values.email, password: values.password, rememberMe: true });
      if (result.error) {
        const message = authErrorMessage(result.error.code);
        setFormError(message); toast.error(message); return;
      }
      if (signup) {
        router.replace(`/signin?registered=1${next !== "/" ? `&next=${encodeURIComponent(next)}` : ""}`);
      } else {
        toast.success("সফলভাবে সাইন ইন হয়েছে!");
        router.replace(next);
      }
      router.refresh();
    } catch { const message = "সংযোগে সমস্যা হয়েছে। ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।"; setFormError(message); toast.error(message); }
    finally { setBusy(null); }
  }

  async function social(provider: "google" | "github") {
    if (busy) return;
    setBusy(provider); setFormError("");
    const callback = new URL(next, window.location.origin);
    callback.searchParams.set("welcome", "1");
    try {
      const result = await authClient.signIn.social({ provider, callbackURL: callback.href, errorCallbackURL: `${window.location.origin}/signin?error=social_login` });
      if (result.error) { const message = authErrorMessage(result.error.code); setFormError(message); toast.error(message); setBusy(null); }
    } catch { toast.error("সাইন ইন শুরু করা যায়নি। আবার চেষ্টা করুন।"); setBusy(null); }
  }

  function fieldError(name: keyof FormValues) { return errors[name] ? <p className="field-error" id={`${name}-error`}>{errors[name]}</p> : null; }
  return <div className="auth-card surface">
    {!availability.ready && <p className="auth-unavailable" role="status">অ্যাকাউন্ট সেবা এখন চালু নেই। একটু পরে আবার চেষ্টা করুন।</p>}
    <form onSubmit={submit} noValidate aria-label={signup ? "নিবন্ধন ফর্ম" : "সাইন ইন ফর্ম"}>
      {formError && <p className="form-error" role="alert">{formError}</p>}
      {signup && <label className="field" htmlFor="name"><span className="field-label">নাম</span><input className="input" id="name" name="name" autoComplete="name" placeholder="যেমন: রহিম উদ্দিন" maxLength={80} required aria-invalid={Boolean(errors.name)} aria-describedby={errors.name ? "name-error" : undefined} />{fieldError("name")}</label>}
      <label className="field" htmlFor="email"><span className="field-label">ইমেইল</span><input className="input" id="email" name="email" type="email" inputMode="email" autoComplete="email" placeholder="you@example.com" required aria-invalid={Boolean(errors.email)} aria-describedby={errors.email ? "email-error" : undefined} />{fieldError("email")}</label>
      <div className="field"><label className="field-label" htmlFor="password">পাসওয়ার্ড</label><div className="password-wrap">
        <input className="input" id="password" name="password" type={visible ? "text" : "password"} autoComplete={signup ? "new-password" : "current-password"} placeholder="কমপক্ষে ৮ অক্ষর" minLength={8} maxLength={128} required aria-invalid={Boolean(errors.password)} aria-describedby={errors.password ? "password-error" : undefined} />
        <button type="button" className="password-toggle" onClick={() => setVisible(!visible)} aria-label={visible ? "পাসওয়ার্ড লুকান" : "পাসওয়ার্ড দেখুন"} aria-pressed={visible}>{visible ? <EyeOff size={16} /> : <Eye size={16} />}</button>
      </div>{fieldError("password")}</div>
      {signup && <label className="field" htmlFor="confirmPassword"><span className="field-label">পাসওয়ার্ড নিশ্চিত করুন</span><input className="input" id="confirmPassword" name="confirmPassword" type={visible ? "text" : "password"} autoComplete="new-password" placeholder="আবার লিখুন" required maxLength={128} aria-invalid={Boolean(errors.confirmPassword)} aria-describedby={errors.confirmPassword ? "confirmPassword-error" : undefined} />{fieldError("confirmPassword")}</label>}
      <button className="btn btn-primary w-full" type="submit" disabled={Boolean(busy) || !availability.ready}>{busy === "email" && <LoaderCircle size={16} className="animate-spin" aria-hidden="true" />}{busy === "email" ? "অপেক্ষা করুন…" : signup ? "অ্যাকাউন্ট তৈরি করুন" : "সাইন ইন"}</button>
    </form>
    <div className="auth-divider">অথবা</div>
    <div className="social-buttons">
      <button type="button" className="btn btn-outline social-button" disabled={Boolean(busy) || !availability.google} onClick={() => social("google")} title={!availability.google ? "Google সাইন ইন এখন উপলব্ধ নয়" : undefined}>{busy === "google" ? <LoaderCircle size={14} className="animate-spin" /> : <GoogleIcon />} Google দিয়ে চালিয়ে যান</button>
      <button type="button" className="btn btn-outline social-button" disabled={Boolean(busy) || !availability.github} onClick={() => social("github")} title={!availability.github ? "GitHub সাইন ইন এখন উপলব্ধ নয়" : undefined}>{busy === "github" ? <LoaderCircle size={14} className="animate-spin" /> : <GithubIcon />} GitHub দিয়ে চালিয়ে যান</button>
    </div>
    <p className="auth-switch">{signup ? "অ্যাকাউন্ট আছে?" : "অ্যাকাউন্ট নেই?"} <Link className="text-link" href={otherHref}>{signup ? "সাইন ইন করুন" : "সাইন আপ করুন"}</Link></p>
  </div>;
}
