import Link from "next/link";
export function EmptyState({ title = "পৃষ্ঠাটি খুঁজে পাওয়া যায়নি", description = "লিংকটি সঠিক নয় অথবা এই পণ্যটি এখন পাওয়া যাচ্ছে না।", code = true }: { title?: string; description?: string; code?: boolean }) {
  return <section className="empty-state surface">
    {code ? <div className="error-code" aria-hidden="true">৪০৪</div> : <span className="empty-icon" aria-hidden="true">🛒</span>}
    <h1>{title}</h1><p>{description}</p><Link href="/" className="btn btn-primary">হোম পেজে ফিরে যান</Link>
  </section>;
}
