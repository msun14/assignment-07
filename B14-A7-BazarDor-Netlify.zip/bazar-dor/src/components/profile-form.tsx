"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { authClient } from "@/lib/auth-client";
import { authErrorMessage } from "@/lib/validation";

export function ProfileForm({ initialName }: { initialName: string }) {
  const [name, setName] = useState(initialName);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function update(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError("");
    if (name.trim().length < 2 || name.trim().length > 80) { const message = "নাম ২ থেকে ৮০ অক্ষরের মধ্যে লিখুন।"; setError(message); toast.error(message); return; }
    setBusy(true);
    try {
      const result = await authClient.updateUser({ name: name.trim() });
      if (result.error) { const message = authErrorMessage(result.error.code); setError(message); toast.error(message); return; }
      toast.success("আপনার তথ্য আপডেট হয়েছে।");
      router.push("/profile"); router.refresh();
    } catch { setError("তথ্য আপডেট হয়নি। আবার চেষ্টা করুন।"); toast.error("তথ্য আপডেট হয়নি। আবার চেষ্টা করুন।"); }
    finally { setBusy(false); }
  }
  return <form className="profile-form" onSubmit={update} noValidate>
    <label className="field" htmlFor="profile-name"><span className="field-label">নাম</span><input className="input" id="profile-name" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" required maxLength={80} aria-invalid={Boolean(error)} aria-describedby={error ? "profile-error" : undefined} /></label>
    {error && <p id="profile-error" className="form-error" role="alert">{error}</p>}
    <button type="submit" className="btn btn-primary w-full" disabled={busy}>{busy ? "আপডেট হচ্ছে…" : "তথ্য আপডেট করুন"}</button>
  </form>;
}
