export function ProductGridSkeleton({ count = 6 }: { count?: number }) {
  return <div className="product-grid" role="status" aria-label="পণ্যের দাম লোড হচ্ছে">
    {Array.from({ length: count }, (_, i) => <div className="product-card skeleton-card" key={i} aria-hidden="true">
      <div className="flex items-center gap-3"><div className="skeleton h-12 w-12 rounded-xl" /><div className="flex-1"><div className="skeleton h-4 w-3/5 rounded" /><div className="skeleton mt-2 h-3 w-1/3 rounded" /></div></div>
      <div className="skeleton mt-5 h-5 w-1/3 rounded" />
    </div>)}
  </div>;
}
export function PageSkeleton() {
  return <div className="container page-space"><div className="skeleton mb-7 h-24 rounded-2xl" /><ProductGridSkeleton /></div>;
}
