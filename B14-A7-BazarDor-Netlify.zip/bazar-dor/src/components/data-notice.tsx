import snapshotMeta from "@/data/snapshot-meta.json";

export function DataNotice({ show }: { show: boolean }) {
  if (!show) return null;
  const date = new Intl.DateTimeFormat("bn-BD", { dateStyle: "medium", timeZone: "Asia/Dhaka" }).format(new Date(snapshotMeta.capturedAt));
  return <p className="data-notice" role="status">এই মুহূর্তে নতুন দাম আনা যাচ্ছে না। {date} তারিখে সংরক্ষিত তথ্য দেখানো হচ্ছে।</p>;
}
