import { toNextJsHandler } from "better-auth/next-js";
import { getAuth } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function handler(request: Request) {
  try {
    const handlers = toNextJsHandler(getAuth());
    return request.method === "GET" ? await handlers.GET(request) : await handlers.POST(request);
  } catch {
    console.error("Authentication service unavailable. Check runtime environment and database migration.");
    return Response.json({ code: "AUTH_SERVICE_UNAVAILABLE", message: "সাইন ইন সেবা সাময়িকভাবে বন্ধ আছে। একটু পরে চেষ্টা করুন।" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
export { handler as GET, handler as POST };
