import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { notFound, redirect } from "next/navigation";
import { getProduct } from "@/lib/api";
import { requireSession } from "@/lib/session";
import { bn, marketSummary, price, unitLabel } from "@/lib/format";
import { DataNotice } from "@/components/data-notice";
import { PriceBadge } from "@/components/price-badge";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
type Props = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const { data } = await getProduct(slug);
  return { title: data ? `${data.nameBn} — বাজারভিত্তিক দাম` : "পণ্য পাওয়া যায়নি", robots: { index: false, follow: true } };
}
export default async function ProductPage({ params }: Props) {
  const { slug } = await params;
  const { data: product, isFallback } = await getProduct(slug);
  if (!product) notFound();
  await requireSession(`/product/${product.slug}`);
  if (slug !== product.slug) redirect(`/product/${product.slug}`);
  const summary = marketSummary(product);
  const sortedMarkets = [...product.markets].sort((a, b) => (a.min + a.max) - (b.min + b.max));
  const changeText = product.change.dir === "up" ? "বেড়েছে" : product.change.dir === "down" ? "কমেছে" : "অপরিবর্তিত রয়েছে";
  return <div className="container page-space">
    <nav className="breadcrumb" aria-label="পৃষ্ঠার অবস্থান"><Link href="/">হোম</Link><ChevronRight size={12} /><Link href={`/category/${product.category}`}>{product.categoryNameBn}</Link><ChevronRight size={12} /><span aria-current="page">{product.nameBn}</span></nav>
    <DataNotice show={isFallback} />
    <section className="surface detail-summary">
      <div className="detail-identity"><span className="product-emoji detail-emoji" aria-hidden="true">{product.image}</span>
        <div><h1>{product.nameBn}</h1><div className="detail-tags"><span>প্রতি {unitLabel(product.unit)}</span><Link className="category-tag" href={`/category/${product.category}`}>{product.categoryNameBn}</Link></div>
          <p>গতকালের তুলনায় আজ দাম {changeText}{product.change.dir !== "flat" ? ` — ${price(Math.abs(product.today - product.yesterday))}` : ""}</p>
        </div>
      </div>
      <div className="today-box"><small>আজকের দাম</small><strong>{bn(product.today)}</strong><small>টাকা / {unitLabel(product.unit)}</small><PriceBadge change={product.change} compact /></div>
    </section>
    <section className="surface market-panel">
      <h2 className="panel-title">দামের সারসংক্ষেপ</h2>
      {summary ? <div className="summary-grid">
        <div className="stat-card surface"><small>সর্বনিম্ন দাম</small><div className="stat-value text-brand">{bn(summary.minimum)} <span>টাকা</span></div><p>সবচেয়ে কম দামের বাজার</p></div>
        <div className="stat-card surface"><small>সর্বোচ্চ দাম</small><div className="stat-value text-red-600">{bn(summary.maximum)} <span>টাকা</span></div><p>সবচেয়ে বেশি দামের বাজার</p></div>
        <div className="stat-card surface"><small>গড় দাম</small><div className="stat-value text-brand">{bn(summary.average, Number.isInteger(summary.average) ? 0 : 2)} <span>টাকা</span></div><p>বাজারগুলোর গড় হিসাবে</p></div>
      </div> : <p className="section-subtitle">বাজারভিত্তিক দাম এখন পাওয়া যাচ্ছে না।</p>}
      <h2 className="panel-title">বাজারভিত্তিক আজকের দাম</h2>
      {sortedMarkets.length > 0 ? <><div className="market-table-wrap" tabIndex={0} role="region" aria-label="বাজারের দামের তুলনা; ছোট পর্দায় পাশে স্ক্রল করুন">
        <table className="market-table"><caption className="sr-only">{product.nameBn}: প্রতি {unitLabel(product.unit)} বাজারভিত্তিক দাম</caption>
          <thead><tr><th scope="col">বাজার</th><th scope="col">বিভাগ</th><th scope="col">সর্বনিম্ন</th><th scope="col">সর্বোচ্চ</th><th scope="col">গড়</th></tr></thead>
          <tbody>{sortedMarkets.map((market, index) => <tr key={`${market.market}-${market.division}-${index}`}><td>{market.market}</td><td>{market.division}</td><td>{price(market.min)}</td><td>{price(market.max)}</td><td>{price((market.min + market.max) / 2)}</td></tr>)}</tbody>
        </table>
      </div><p className="table-note">গড় = প্রতিটি বাজারের সর্বনিম্ন ও সর্বোচ্চ দামের মধ্যমান। সারসংক্ষেপে এই মধ্যমানগুলোর গড় দেখানো হয়েছে।</p></> : <p className="muted">এই পণ্যের বাজারভিত্তিক দাম পাওয়া যায়নি।</p>}
    </section>
  </div>;
}
