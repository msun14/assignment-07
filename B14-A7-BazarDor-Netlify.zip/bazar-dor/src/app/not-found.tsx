import { EmptyState } from "@/components/empty-state";
export default function NotFound() { return <div className="container page-space"><EmptyState /></div>; }
