import Link from "next/link";
import { AuthForm } from "@/components/auth-form";
import { authAvailability } from "@/lib/auth-config";
import { safeReturnPath } from "@/lib/format";

export const metadata = { title: "অ্যাকাউন্ট তৈরি করুন", robots: { index: false, follow: true } };
export const dynamic = "force-dynamic";
export default async function SignUpPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  return <section className="auth-page"><div className="auth-heading"><h1>অ্যাকাউন্ট তৈরি করুন</h1><p>বিনা খরচে সাইন আপ করে সব বিস্তারিত দাম দেখুন।</p></div>
    <AuthForm mode="signup" returnTo={safeReturnPath(next)} availability={authAvailability()} />
    <Link href="/" className="back-link">← হোম পেজে ফিরে যান</Link>
  </section>;
}
