import Image from "next/image";
import { Suspense } from "react";
import { DateText } from "@/components/header";
import { HomeCatalog } from "@/components/home-catalog";
import { ProductGridSkeleton } from "@/components/skeletons";

export default function HomePage() {
  return <div className="container page-space">
    <section className="hero surface" aria-labelledby="hero-title">
      <div><DateText className="hero-eyebrow" />
        <h1 id="hero-title">আজকের বাজারের দাম এক নজরে</h1>
        <p>চাল, ডাল, তেল, সবজি, মাছ, মাংস, ডিম ও মসলার দাম — বাজারভিত্তিক বিস্তারিত, গড়, সর্বনিম্ন-সর্বোচ্চ এবং দামের পরিবর্তন এক জায়গায়!</p>
        <a href="#সব-পণ্য" className="btn btn-primary">সব পণ্য দেখুন</a>
      </div>
      <Image className="hero-image" src="/market-basket.svg" width={280} height={230} alt="তাজা ফল ও সবজির বাজারের ঝুড়ি" priority />
    </section>
    <Suspense fallback={<section className="product-section"><h2 className="section-heading">আজকের বাজারদর</h2><ProductGridSkeleton /></section>}><HomeCatalog /></Suspense>
  </div>;
}
