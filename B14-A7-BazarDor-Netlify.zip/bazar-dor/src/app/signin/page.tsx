import Link from "next/link";
import { AuthForm } from "@/components/auth-form";
import { authAvailability } from "@/lib/auth-config";
import { safeReturnPath } from "@/lib/format";

export const metadata = { title: "সাইন ইন", robots: { index: false, follow: true } };
export const dynamic = "force-dynamic";
export default async function SignInPage({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  return <section className="auth-page"><div className="auth-heading"><h1>সাইন ইন</h1><p>বিস্তারিত দাম, বাজার তুলনা ও প্রোফাইল দেখতে অ্যাকাউন্টে ঢুকুন।</p></div>
    <AuthForm mode="signin" returnTo={safeReturnPath(next)} availability={authAvailability()} />
    <Link href="/" className="back-link">← হোম পেজে ফিরে যান</Link>
  </section>;
}
