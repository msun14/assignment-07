"use client";
import Link from "next/link";
export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <div className="container page-space"><section className="empty-state surface">
    <span className="empty-icon" aria-hidden="true">🛒</span><h1>এই মুহূর্তে পৃষ্ঠাটি খুলছে না</h1>
    <p>সাময়িক সংযোগ সমস্যার কারণে তথ্য আনা যায়নি। একটু পরে আবার চেষ্টা করুন।</p>
    <div className="flex justify-center gap-3"><button onClick={reset} className="btn btn-primary">আবার চেষ্টা করুন</button><Link href="/" className="btn btn-outline">হোম পেজে ফিরে যান</Link></div>
  </section></div>;
}
