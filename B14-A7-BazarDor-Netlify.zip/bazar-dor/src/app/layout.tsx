import type { Metadata } from "next";
import { Suspense } from "react";
import "@fontsource/hind-siliguri/400.css";
import "@fontsource/hind-siliguri/500.css";
import "@fontsource/hind-siliguri/600.css";
import "@fontsource/hind-siliguri/700.css";
import "./globals.css";
import { Providers } from "@/components/providers";
import { Footer, SiteChrome } from "@/components/site-chrome";
import { SiteHeader } from "@/components/header";
import categories from "@/data/categories.snapshot.json";

export const metadata: Metadata = {
  title: { default: "বাজার দর — আজকের বাজারের দাম এক নজরে", template: "%s | বাজার দর" },
  description: "চাল, ডাল, তেল, সবজি, মাছ, মাংস, ডিম ও মসলার বাজারভিত্তিক দাম, তুলনা ও পরিবর্তন দেখুন এক জায়গায়।",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="bn"><body><Providers>
    <a href="#main-content" className="skip-link">মূল কনটেন্টে যান</a>
    <Suspense fallback={<><SiteHeader categories={categories} /><div className="skeleton h-10" /></>}><SiteChrome /></Suspense>
    <main id="main-content" className="main-content">{children}</main>
    <Footer />
  </Providers></body></html>;
}
