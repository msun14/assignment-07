import Link from "next/link";
import { requireSession } from "@/lib/session";
import { Avatar } from "@/components/avatar";
import { LogoutButton } from "@/components/logout-button";

export const metadata = { title: "আমার প্রোফাইল", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export default async function ProfilePage() {
  const { user } = await requireSession("/profile");
  return <div className="container profile-page page-space">
    <div className="profile-heading"><h1>আমার প্রোফাইল</h1><p>আপনার অ্যাকাউন্টের তথ্য এখানে দেখুন।</p></div>
    <section className="profile-summary surface"><Avatar name={user.name} image={user.image} large /><div className="profile-identity"><h2>{user.name}</h2><p>{user.email}</p></div><LogoutButton /></section>
    <section className="profile-panel surface"><h2 className="panel-title">তথ্য</h2>
      <dl className="profile-info"><div><dt>নাম</dt><dd>{user.name}</dd></div><div><dt>ইমেইল</dt><dd>{user.email}</dd></div></dl>
      <Link href="/profile/edit" className="btn btn-primary w-full">তথ্য আপডেট করুন</Link>
    </section>
  </div>;
}
