import Link from "next/link";
import { requireSession } from "@/lib/session";
import { Avatar } from "@/components/avatar";
import { ProfileForm } from "@/components/profile-form";

export const metadata = { title: "প্রোফাইল আপডেট", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export default async function EditProfilePage() {
  const { user } = await requireSession("/profile/edit");
  return <div className="container profile-page page-space">
    <div className="profile-heading"><h1>আমার প্রোফাইল</h1><p>আপনার অ্যাকাউন্টের তথ্য আপডেট করুন।</p></div>
    <section className="profile-summary surface"><Avatar name={user.name} image={user.image} large /><div className="profile-identity"><h2>{user.name}</h2><p>{user.email}</p></div></section>
    <section className="profile-panel surface"><h2 className="panel-title">তথ্য</h2><ProfileForm initialName={user.name} /></section>
    <Link href="/profile" className="back-link">← প্রোফাইলে ফিরে যান</Link>
  </div>;
}
