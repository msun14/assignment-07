import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getCategory, getProducts } from "@/lib/api";
import { bn } from "@/lib/format";
import { CategoryProducts } from "@/components/category-products";
import { DataNotice } from "@/components/data-notice";
import { EmptyState } from "@/components/empty-state";

type Props = { params: Promise<{ slug: string }> };
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategory(slug);
  return { title: category ? `${category.nameBn} — আজকের দাম` : "বিভাগ পাওয়া যায়নি" };
}
export default async function CategoryPage({ params }: Props) {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) notFound();
  const { data: products, isFallback } = await getProducts(category.slug);
  return <div className="container page-space">
    <section className="category-banner surface"><span className="category-icon" aria-hidden="true">{category.icon}</span>
      <div><h1>{category.nameBn}</h1><p>{bn(products.length)}টি পণ্যের আজকের দাম ও পরিবর্তন</p></div>
    </section>
    <DataNotice show={isFallback} />
    {products.length ? <CategoryProducts key={slug} products={products} /> : <EmptyState code={false} title="এই বিভাগে এখন কোনো পণ্য নেই" description="নতুন দাম যোগ হলে এখানে দেখা যাবে। অন্য বিভাগের পণ্য দেখতে হোম পেজে যান।" />}
  </div>;
}
