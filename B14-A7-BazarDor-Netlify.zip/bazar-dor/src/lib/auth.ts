import "server-only";
import { createBazarAuth } from "./auth-config";
import { getDatabase } from "./db";

let instance: ReturnType<typeof createBazarAuth> | undefined;
// Lazy initialization lets public pages build without opening a DB connection.
export function getAuth() { return instance ??= createBazarAuth(getDatabase()); }
