"use client";
import { createAuthClient } from "better-auth/react";

// Same-origin requests preserve cookies on localhost and any configured Netlify domain.
export const authClient = createAuthClient();
