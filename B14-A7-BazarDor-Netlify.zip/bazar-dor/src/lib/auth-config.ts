import { betterAuth } from "better-auth/minimal";
import { drizzleAdapter } from "better-auth/adapters/drizzle";
import * as schema from "./db/schema";

type Environment = Record<string, string | undefined>;

export function authAvailability(env: Environment = process.env) {
  let validOrigin = false;
  try {
    const url = new URL(env.BETTER_AUTH_URL || "");
    validOrigin = ["http:", "https:"].includes(url.protocol) && url.pathname === "/" && !url.search && !url.hash;
  } catch { /* Missing configuration leaves account services unavailable. */ }
  const ready = Boolean(env.DATABASE_URL && !env.DATABASE_URL.includes("USER:PASSWORD@HOST") && env.BETTER_AUTH_SECRET && env.BETTER_AUTH_SECRET.length >= 32 && !env.BETTER_AUTH_SECRET.startsWith("replace-with") && validOrigin);
  return {
    ready,
    google: Boolean(ready && env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET),
    github: Boolean(ready && env.GITHUB_CLIENT_ID && env.GITHUB_CLIENT_SECRET),
  };
}

export function createBazarAuth(database: Parameters<typeof drizzleAdapter>[0], env: Environment = process.env) {
  const secret = env.BETTER_AUTH_SECRET;
  if (!secret || secret.length < 32 || secret.startsWith("replace-with")) throw new Error("A strong BETTER_AUTH_SECRET is required");
  if (!env.BETTER_AUTH_URL) throw new Error("BETTER_AUTH_URL is required");
  const baseURL = new URL(env.BETTER_AUTH_URL).origin;
  const additionalOrigins = (env.BETTER_AUTH_TRUSTED_ORIGINS ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  return betterAuth({
    appName: "বাজার দর",
    baseURL,
    secret,
    database: drizzleAdapter(database, { provider: "pg", schema }),
    trustedOrigins: [baseURL, ...additionalOrigins],
    emailAndPassword: {
      enabled: true,
      minPasswordLength: 8,
      maxPasswordLength: 128,
      requireEmailVerification: false,
      autoSignIn: false,
    },
    socialProviders: {
      ...(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET ? {
        google: { clientId: env.GOOGLE_CLIENT_ID, clientSecret: env.GOOGLE_CLIENT_SECRET, prompt: "select_account" as const },
      } : {}),
      ...(env.GITHUB_CLIENT_ID && env.GITHUB_CLIENT_SECRET ? {
        github: { clientId: env.GITHUB_CLIENT_ID, clientSecret: env.GITHUB_CLIENT_SECRET, scope: ["read:user", "user:email"] },
      } : {}),
    },
    session: { expiresIn: 60 * 60 * 24 * 7, updateAge: 60 * 60 * 24, cookieCache: { enabled: false } },
    advanced: { useSecureCookies: baseURL.startsWith("https://") },
    databaseHooks: {
      user: {
        create: { before: async (user) => ({ data: { ...user, name: user.name.trim().slice(0, 80) || "ব্যবহারকারী" } }) },
        update: { before: async (user) => ({ data: { ...user, ...(typeof user.name === "string" ? { name: user.name.trim().slice(0, 80) || "ব্যবহারকারী" } : {}) } }) },
      },
    },
  });
}
