import type { Product, SortOrder } from "./types";

const bengaliDigits = "০১২৩৪৫৬৭৮৯";

export function numeric(value: unknown): number {
  if (typeof value === "number") return Number.isFinite(value) ? value : NaN;
  if (typeof value !== "string") return NaN;
  const normalized = value.replace(/[০-৯]/g, (digit) => String(bengaliDigits.indexOf(digit)))
    .replace(/,/g, "").trim();
  return normalized ? Number(normalized) : NaN;
}

export function bn(value: number, decimals = 0): string {
  return new Intl.NumberFormat("bn-BD", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

export function price(value: number): string { return `${bn(value, Number.isInteger(value) ? 0 : 2)} টাকা`; }
export function unitLabel(unit: string): string {
  return ({ kg: "কেজি", litre: "লিটার", liter: "লিটার", dozen: "ডজন", piece: "পিস", pc: "পিস" } as Record<string, string>)[unit] ?? unit;
}
export function banglaDate(date: Date = new Date()): string {
  return new Intl.DateTimeFormat("bn-BD", { timeZone: "Asia/Dhaka", weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(date);
}
export function sortProducts(products: Product[], order: SortOrder): Product[] {
  if (order === "default") return [...products];
  return [...products].sort((a, b) => order === "asc" ? numeric(a.today) - numeric(b.today) : numeric(b.today) - numeric(a.today));
}
export function topMovers(products: Product[], direction: "up" | "down"): Product[] {
  return products.filter((p) => p.change.dir === direction)
    .sort((a, b) => Math.abs(b.change.pct) - Math.abs(a.change.pct)).slice(0, 6);
}
export function marketSummary(product: Product) {
  if (!product.markets.length) return null;
  const minimum = Math.min(...product.markets.map((m) => m.min));
  const maximum = Math.max(...product.markets.map((m) => m.max));
  const average = product.markets.reduce((sum, m) => sum + (m.min + m.max) / 2, 0) / product.markets.length;
  return { minimum, maximum, average: Math.round(average * 100) / 100 };
}

// Only allow app-owned destinations; never redirect to a supplied external URL.
export function safeReturnPath(value: unknown): string {
  if (typeof value !== "string" || !value.startsWith("/") || value.startsWith("//") || /[\\\u0000-\u0020]/.test(value)) return "/";
  try {
    const url = new URL(value, "https://bazardor.local");
    if (url.origin !== "https://bazardor.local" || /^\/(?:api|signin|signup)(?:\/|$)/.test(url.pathname)) return "/";
    return `${url.pathname}${url.search}${url.hash}`;
  } catch { return "/"; }
}
