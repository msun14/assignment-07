import "server-only";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { getAuth } from "./auth";
import { safeReturnPath } from "./format";

export async function requireSession(returnTo: string) {
  const requestHeaders = await headers();
  const destination = `/signin?reason=protected&next=${encodeURIComponent(safeReturnPath(returnTo))}`;
  if (!(requestHeaders.get("cookie") ?? "").includes("better-auth.session_token=")) redirect(destination);
  // A cookie's presence alone never grants access: validate against the database.
  const session = await getAuth().api.getSession({ headers: requestHeaders });
  if (!session) redirect(destination);
  return session;
}
