import "server-only";
import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import * as schema from "./schema";

const globalDb = globalThis as unknown as { bazarPool?: Pool };
export function getDatabase() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is not configured");
  // Small, reused pools suit serverless functions. SSL follows the connection URL.
  globalDb.bazarPool ??= new Pool({ connectionString, max: 3, idleTimeoutMillis: 10000, connectionTimeoutMillis: 10000 });
  return drizzle(globalDb.bazarPool, { schema });
}
