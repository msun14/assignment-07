import { numeric } from "./format";
import type { Category, Market, Product } from "./types";

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid API object");
  return value as Record<string, unknown>;
}
function text(value: unknown): string {
  if (typeof value !== "string" || !value.trim()) throw new Error("Missing API text");
  return value;
}
function number(value: unknown): number {
  const result = numeric(value);
  if (!Number.isFinite(result) || result < 0) throw new Error("Invalid price");
  return result;
}
export function unwrapList(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  const obj = record(value);
  const result = obj.data ?? obj.products ?? obj.categories;
  if (!Array.isArray(result)) throw new Error("Invalid API list");
  return result;
}
export function normalizeCategory(value: unknown): Category {
  const obj = record(value);
  const slug = text(obj.slug ?? obj.id);
  return { id: String(obj.id ?? slug), slug, nameBn: text(obj.nameBn), icon: text(obj.icon) };
}
export function normalizeProduct(value: unknown): Product {
  const obj = record(value);
  const today = number(obj.today);
  const yesterday = number(obj.yesterday);
  const delta = yesterday > 0 ? ((today - yesterday) / yesterday) * 100 : 0;
  const change = obj.change && typeof obj.change === "object" ? record(obj.change) : null;
  const pct = change ? numeric(change.pct) : Math.round(delta * 10) / 10;
  if (!Number.isFinite(pct)) throw new Error("Invalid price movement");
  const markets: Market[] = Array.isArray(obj.markets) ? obj.markets.map((m) => {
    const item = record(m);
    const min = number(item.min), max = number(item.max);
    if (min > max) throw new Error("Invalid market range");
    return { market: text(item.market), division: text(item.division), min, max };
  }) : [];
  const slug = text(obj.slug);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug)) throw new Error("Invalid product slug");
  return {
    id: number(obj.id), slug, nameBn: text(obj.nameBn), category: text(obj.category),
    categoryNameBn: text(obj.categoryNameBn), categoryIcon: text(obj.categoryIcon),
    unit: text(obj.unit), image: text(obj.image), today, yesterday,
    lastWeek: number(obj.lastWeek ?? today), lastMonth: number(obj.lastMonth ?? today),
    change: { dir: today > yesterday ? "up" : today < yesterday ? "down" : "flat", pct }, markets,
  };
}
