import "server-only";
import { cache } from "react";
import productsSnapshot from "@/data/products.snapshot.json";
import categoriesSnapshot from "@/data/categories.snapshot.json";
import { normalizeCategory, normalizeProduct, unwrapList } from "./normalize";
import type { Category, DataResult, Product } from "./types";

const API = (process.env.BAZARDOR_API_URL || "https://openapi.programming-hero.com/api/bazardor").replace(/\/$/, "");

async function request(path: string): Promise<unknown> {
  const response = await fetch(`${API}${path}`, {
    next: { revalidate: 300 },
    signal: AbortSignal.timeout(7000),
    headers: { Accept: "application/json" },
  });
  if (!response.ok) throw new Error(`Market API HTTP ${response.status}`);
  return response.json();
}

export const getCategories = cache(async (): Promise<DataResult<Category[]>> => {
  try { return { data: unwrapList(await request("/categories")).map(normalizeCategory), isFallback: false }; }
  catch { return { data: categoriesSnapshot.map(normalizeCategory), isFallback: true }; }
});

export const getProducts = cache(async (category?: string): Promise<DataResult<Product[]>> => {
  const path = category ? `/products?category=${encodeURIComponent(category)}` : "/products";
  try {
    const data = unwrapList(await request(path)).map(normalizeProduct);
    return { data: category ? data.filter((p) => p.category === category) : data, isFallback: false };
  } catch {
    const data = productsSnapshot.map(normalizeProduct);
    return { data: category ? data.filter((p) => p.category === category) : data, isFallback: true };
  }
});

export const getCategory = cache(async (slug: string): Promise<Category | null> => {
  if (!/^[a-z0-9-]+$/.test(slug)) return null;
  const { data } = await getCategories();
  const known = data.find((c) => c.slug === slug);
  if (!known) return null;
  try {
    const raw = await request(`/categories/${encodeURIComponent(slug)}`);
    const obj = raw as { data?: unknown };
    const category = normalizeCategory(obj.data ?? raw);
    return category.slug === slug ? category : known;
  } catch { return known; }
});

export const getProduct = cache(async (slug: string): Promise<DataResult<Product | null>> => {
  if (!/^[a-z0-9-]+$/.test(slug)) return { data: null, isFallback: false };
  const catalog = await getProducts();
  // The API accepts an ID, while the app uses readable slugs.
  const existing = catalog.data.find((p) => p.slug === slug || String(p.id) === slug);
  if (!existing) return { data: null, isFallback: catalog.isFallback };
  try {
    const raw = await request(`/products/${existing.id}`);
    const obj = raw as { data?: unknown };
    const product = normalizeProduct(obj.data ?? raw);
    if (product.id !== existing.id) throw new Error("Unexpected product response");
    return { data: product, isFallback: false };
  } catch { return { data: existing, isFallback: catalog.isFallback }; }
});
