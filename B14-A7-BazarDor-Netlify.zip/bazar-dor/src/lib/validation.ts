export type FormValues = { name?: string; email: string; password: string; confirmPassword?: string };
export type FormErrors = Partial<Record<keyof FormValues, string>>;
export function validateAuth(values: FormValues, signup: boolean): FormErrors {
  const errors: FormErrors = {};
  if (signup && (!values.name || values.name.trim().length < 2 || values.name.trim().length > 80)) errors.name = "নাম ২ থেকে ৮০ অক্ষরের মধ্যে লিখুন।";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) errors.email = "সঠিক ইমেইল ঠিকানা লিখুন।";
  if (values.password.length < 8 || values.password.length > 128) errors.password = "পাসওয়ার্ড ৮ থেকে ১২৮ অক্ষরের মধ্যে হতে হবে।";
  if (signup && values.password !== values.confirmPassword) errors.confirmPassword = "পাসওয়ার্ড দুটি মিলছে না।";
  return errors;
}
export function authErrorMessage(code?: string): string {
  const messages: Record<string, string> = {
    INVALID_EMAIL_OR_PASSWORD: "ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।",
    USER_ALREADY_EXISTS: "এই ইমেইলে একটি অ্যাকাউন্ট আছে। সাইন ইন করুন।",
    USER_ALREADY_EXISTS_USE_ANOTHER_EMAIL: "এই ইমেইলে একটি অ্যাকাউন্ট আছে। সাইন ইন করুন।",
    INVALID_EMAIL: "সঠিক ইমেইল ঠিকানা লিখুন।",
    PASSWORD_TOO_SHORT: "পাসওয়ার্ডে অন্তত ৮টি অক্ষর থাকতে হবে।",
    PASSWORD_TOO_LONG: "পাসওয়ার্ড ১২৮ অক্ষরের বেশি হতে পারবে না।",
    TOO_MANY_REQUESTS: "অনেকবার চেষ্টা করা হয়েছে। একটু পরে আবার চেষ্টা করুন।",
    AUTH_SERVICE_UNAVAILABLE: "সাইন ইন সেবা সাময়িকভাবে বন্ধ আছে। একটু পরে চেষ্টা করুন।",
    INVALID_ORIGIN: "সাইন ইন সংযোগে সমস্যা হয়েছে। সাইটের সঠিক ঠিকানায় আবার চেষ্টা করুন।",
    SESSION_EXPIRED: "সেশনের মেয়াদ শেষ। আবার সাইন ইন করুন।",
  };
  return messages[code || ""] || "অনুরোধটি সম্পন্ন হয়নি। আবার চেষ্টা করুন।";
}
